# AI Video Extractor Privacy Policy

**Effective date:** 14 October 2026  
**Developer:** AI Video Extractor developer  
**Contact:** Replace this line with a monitored support email before publishing.

AI Video Extractor processes selected videos on your Android device. This policy explains what the app and its advertising and consent SDKs process.

## Video files and links

Videos selected from your device are read locally for preview and extraction. The app writes finished MP4 files to your device's Movies folder. Temporary processing files are kept in app storage and are deleted after processing where possible. The app does not upload selected videos, preview frames, or finished clips to an AI Video Extractor server.

The app only processes video files chosen locally from your device storage. It does not download or extract content from online URLs or websites.

## Advertising and consent

The app uses Google Mobile Ads SDK to request banner and App Open ads. Debug builds use Google's test ad units. Production builds use the AdMob IDs configured by the developer. If separately configured, the app can also request interstitial and rewarded ads.

Google Mobile Ads may collect or receive IP address, app interactions, diagnostics, device and account identifiers (including advertising ID when available), and ad-related information for advertising, analytics, fraud prevention, and service operation. Google processes this information under its own terms and privacy policy: [Google Privacy Policy](https://policies.google.com/privacy).

The Google User Messaging Platform (UMP) SDK requests and stores consent choices and presents privacy messages when required. You can reopen the app's **Privacy options** control when it is displayed. Ads are requested only when UMP reports that requests are permitted.

The app stores the rewarded-ad expiration time and an interstitial frequency counter locally on the device. These settings are not sent to an AI Video Extractor server.

## Information collected by the developer

The app has no developer-operated account, analytics, or video-upload service. The developer does not receive selected videos or clips through the app. Google processes advertising information as described in its own policies.

## Retention and deletion

Output videos remain in your device's Movies folder until you delete them. Temporary files are deleted after processing where possible; you may clear the app's storage using Android settings to remove remaining app data. UMP and Google Mobile Ads retain data according to their policies and settings.

## Children

The app is not designed for children under 13 and is not directed to children. The developer must review the target audience and applicable child-directed-app requirements before publishing or serving ads.

## Security and policy changes

The app has no developer-operated server storing video content. Keep Android and the app updated. This policy may change if app functionality or SDKs change; the effective date above will be updated when the policy is revised.

## Contact

For privacy questions or requests, contact the developer at the support email that will be published with the app. **Replace the contact placeholder above with the developer's real monitored email before publishing.**
