import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val adsProperties = Properties().apply {
    val configFile = rootProject.file("ads.properties")
    if (configFile.isFile) configFile.inputStream().use { input -> load(input) }
}
val configuredAdMobAppId = adsProperties.getProperty("admobAppId", "").trim()
val configuredBannerAdUnitId = adsProperties.getProperty("bannerAdUnitId", "").trim()
val configuredAppOpenAdUnitId = adsProperties.getProperty("appOpenAdUnitId", "").trim()
val configuredInterstitialAdUnitId = adsProperties.getProperty("interstitialAdUnitId", "").trim()
val configuredRewardedAdUnitId = adsProperties.getProperty("rewardedAdUnitId", "").trim()

val testAdMobAppId = "ca-app-pub-3940256099942544~3347511713"
val testBannerAdUnitId = "ca-app-pub-3940256099942544/9214589741"
val testAppOpenAdUnitId = "ca-app-pub-3940256099942544/9257395921"
val testInterstitialAdUnitId = "ca-app-pub-3940256099942544/1033173712"
val testRewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917"

// Testing flag: if useTestBanner is true (or defaulted for testing),
// Google's official Android banner test ad unit ID is used in release builds for testing
// while keeping production IDs completely separate and untouched.
val useTestBanner = adsProperties.getProperty("useTestBanner", "true").trim().toBoolean()

val effectiveBannerAdUnitId = if (useTestBanner) {
    testBannerAdUnitId
} else if (configuredBannerAdUnitId.isNotBlank()) {
    configuredBannerAdUnitId
} else {
    testBannerAdUnitId
}

val effectiveAdMobAppId = if (useTestBanner && configuredAdMobAppId.isBlank()) {
    testAdMobAppId
} else if (configuredAdMobAppId.isNotBlank()) {
    configuredAdMobAppId
} else {
    testAdMobAppId
}

val releaseAdsEnabled = effectiveAdMobAppId.isNotBlank() && listOf(
    effectiveBannerAdUnitId,
    configuredAppOpenAdUnitId,
    configuredInterstitialAdUnitId,
    configuredRewardedAdUnitId,
).any { it.isNotBlank() }

android {
    namespace = "com.aivideoextractor.mobile"
    // Compile against the installed stable platform while targeting API 36 for current Play submission policy.
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aivideoextractor.mobile"
        minSdk = 29
        targetSdk = 36
        versionCode = 5
        versionName = "1.3.1"
        manifestPlaceholders["admobAppId"] = testAdMobAppId
        resValue("bool", "ads_enabled", "false")
        resValue("string", "banner_ad_unit_id", "")
        resValue("string", "app_open_ad_unit_id", "")
        resValue("string", "interstitial_ad_unit_id", "")
        resValue("string", "rewarded_ad_unit_id", "")
    }
    signingConfigs {
        create("localDebug") {
            storeFile = file("$rootDir/.build-cache/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        val releaseSigningFile = rootProject.file(".build-cache/release-signing.properties")
        if (releaseSigningFile.isFile) {
            val releaseProperties = Properties().apply {
                releaseSigningFile.inputStream().use { input -> load(input) }
            }
            create("localRelease") {
                storeFile = rootProject.file(releaseProperties.getProperty("storeFile"))
                storePassword = releaseProperties.getProperty("storePassword")
                keyAlias = releaseProperties.getProperty("keyAlias")
                keyPassword = releaseProperties.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("localDebug")
            manifestPlaceholders["admobAppId"] = testAdMobAppId
            resValue("bool", "ads_enabled", "true")
            resValue("string", "banner_ad_unit_id", testBannerAdUnitId)
            resValue("string", "app_open_ad_unit_id", testAppOpenAdUnitId)
            resValue("string", "interstitial_ad_unit_id", testInterstitialAdUnitId)
            resValue("string", "rewarded_ad_unit_id", testRewardedAdUnitId)
        }
        getByName("release") {
            val releaseSigningFile = rootProject.file(".build-cache/release-signing.properties")
            if (releaseSigningFile.isFile && signingConfigs.findByName("localRelease") != null) {
                signingConfig = signingConfigs.getByName("localRelease")
            } else {
                signingConfig = signingConfigs.getByName("localDebug")
            }
            isMinifyEnabled = false
            manifestPlaceholders["admobAppId"] = effectiveAdMobAppId
            resValue("bool", "ads_enabled", releaseAdsEnabled.toString())
            resValue("string", "banner_ad_unit_id", if (releaseAdsEnabled) effectiveBannerAdUnitId else "")
            resValue("string", "app_open_ad_unit_id", if (releaseAdsEnabled && !useTestBanner) configuredAppOpenAdUnitId else "")
            resValue("string", "interstitial_ad_unit_id", if (releaseAdsEnabled && !useTestBanner) configuredInterstitialAdUnitId else "")
            resValue("string", "rewarded_ad_unit_id", if (releaseAdsEnabled && !useTestBanner) configuredRewardedAdUnitId else "")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
    packaging { jniLibs.useLegacyPackaging = false }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.05.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.0")
    implementation("androidx.lifecycle:lifecycle-process:2.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
