package com.aivideoextractor.mobile

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import android.view.ViewGroup
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.min
import kotlin.math.floor

private val UNIT_SECONDS = mapOf("seconds" to 1, "minutes" to 60, "hours" to 3600)
private const val APP_NAME = "AI Video Extractor"
private const val TAG_ADS = "AIVideoExtractorAds"
private const val AD_FREE_HOUR_MS = 60L * 60L * 1000L
private const val EXPORTS_PER_INTERSTITIAL = 3
private const val PREFS_ADS = "ad_preferences"
private const val KEY_AD_FREE_UNTIL = "ad_free_until"
private const val KEY_EXPORTS_SINCE_INTERSTITIAL = "successful_exports_since_interstitial"
private const val KEY_LAST_APP_OPEN_SHOWN = "last_app_open_shown"
private const val APP_OPEN_AD_MAX_AGE_MS = 4L * 60L * 60L * 1000L
private const val APP_OPEN_COOLDOWN_MS = 4L * 60L * 60L * 1000L

class MainActivity : ComponentActivity() {
    private val adsEnabled get() = resources.getBoolean(R.bool.ads_enabled)
    private val bannerAdUnitId get() = getString(R.string.banner_ad_unit_id)
    private val appOpenAdUnitId get() = getString(R.string.app_open_ad_unit_id)
    private val interstitialAdUnitId get() = getString(R.string.interstitial_ad_unit_id)
    private val rewardedAdUnitId get() = getString(R.string.rewarded_ad_unit_id)
    @Volatile private var activeSession: FFmpegSession? = null
    @Volatile private var cancelRequested = false
    private var adsReady by mutableStateOf(false)
    private var privacyOptionsRequired by mutableStateOf(false)
    private var adsInitializationStarted = false
    private var interstitialAd: InterstitialAd? = null
    private var interstitialLoading = false
    private var interstitialLoadedAt = 0L
    private var rewardedAd: RewardedAd? = null
    private var rewardedAdReady by mutableStateOf(false)
    private var rewardedLoading = false
    private var rewardedLoadedAt = 0L
    private var adFreeUntilMillis by mutableLongStateOf(0L)
    private var adFreeActive by mutableStateOf(false)
    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoading = false
    private var appOpenLoadedAt = 0L
    private var appOpenShowing = false
    private var processWasBackgrounded = false
    private var consentUiShowing = false
    private var consentFlowComplete = false
    private var extractionBusy = false
    private var fullScreenAdShowing = false
    private val processLifecycleObserver = LifecycleEventObserver { _, event ->
        when (event) {
            Lifecycle.Event.ON_STOP -> processWasBackgrounded = true
            Lifecycle.Event.ON_START -> if (processWasBackgrounded) {
                processWasBackgrounded = false
                onReturnToForeground()
            }
            else -> Unit
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProcessLifecycleOwner.get().lifecycle.addObserver(processLifecycleObserver)
        restoreAdFreeReward()
        requestAdConsentIfConfigured()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF5145CD))) { MobileScreen() } }
    }

    override fun onDestroy() {
        ProcessLifecycleOwner.get().lifecycle.removeObserver(processLifecycleObserver)
        super.onDestroy()
    }

    private fun requestAdConsentIfConfigured() {
        if (!adsEnabled) return
        consentUiShowing = true
        Log.d(TAG_ADS, "Requesting UMP consent information update...")
        val consentInformation = UserMessagingPlatform.getConsentInformation(this)
        val parameters = ConsentRequestParameters.Builder().build()
        consentInformation.requestConsentInfoUpdate(
            this,
            parameters,
            {
                Log.d(TAG_ADS, "UMP consent info update succeeded. canRequestAds=${consentInformation.canRequestAds()}, status=${consentInformation.consentStatus}")
                updatePrivacyOptionsState(consentInformation)
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { formError ->
                    if (formError != null) Log.w(TAG_ADS, "Consent form unavailable: ${formError.message}")
                    consentUiShowing = false
                    consentFlowComplete = true
                    updatePrivacyOptionsState(consentInformation)
                    initializeAdsIfAllowed(consentInformation)
                    if (adsReady) loadAppOpenAd()
                }
            },
            { error ->
                Log.w(TAG_ADS, "Consent information update failed (code=${error.errorCode}): ${error.message}")
                consentUiShowing = false
                consentFlowComplete = true
                updatePrivacyOptionsState(consentInformation)
                initializeAdsIfAllowed(consentInformation)
                if (adsReady) loadAppOpenAd()
            },
        )
        // UMP may already have a valid choice from the previous session.
        initializeAdsIfAllowed(consentInformation)
    }

    private fun updatePrivacyOptionsState(consentInformation: ConsentInformation) {
        privacyOptionsRequired = consentInformation.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
    }

    private fun initializeAdsIfAllowed(consentInformation: ConsentInformation) {
        val canRequest = consentInformation.canRequestAds()
        Log.d(TAG_ADS, "initializeAdsIfAllowed: adsInitializationStarted=$adsInitializationStarted, adsEnabled=$adsEnabled, canRequestAds=$canRequest, consentFlowComplete=$consentFlowComplete")
        if (adsInitializationStarted || !adsEnabled) return
        if (!canRequest && !consentFlowComplete) return
        adsInitializationStarted = true
        Log.d(TAG_ADS, "Initializing Google Mobile Ads SDK...")
        Thread({
            MobileAds.initialize(applicationContext) { status ->
                runOnUiThread {
                    status.adapterStatusMap.forEach { (adapter, adapterStatus) ->
                        Log.d(TAG_ADS, "AdMob Adapter $adapter: ${adapterStatus.initializationState} (${adapterStatus.description})")
                    }
                    adsReady = true
                    loadAppOpenAd()
                    loadInterstitialAd()
                    loadRewardedAd()
                }
            }
        }, "google-mobile-ads-init").start()
    }

    private fun loadAppOpenAd() {
        if (!adsEnabled || !adsReady || !consentFlowComplete || appOpenAdUnitId.isBlank() || appOpenLoading || appOpenAd != null) return
        appOpenLoading = true
        AppOpenAd.load(this, appOpenAdUnitId, AdRequest.Builder().build(), object : AppOpenAdLoadCallback() {
            override fun onAdLoaded(ad: AppOpenAd) {
                appOpenLoading = false
                appOpenAd = ad
                appOpenLoadedAt = System.currentTimeMillis()
                Log.d(TAG_ADS, "App Open ad loaded.")
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                appOpenLoading = false
                appOpenAd = null
                Log.w(TAG_ADS, "App Open ad failed (${error.code}): ${error.message}")
            }
        })
    }

    private fun onReturnToForeground() {
        if (!adsEnabled || !adsReady || !consentFlowComplete || consentUiShowing || adFreeActive || extractionBusy || fullScreenAdShowing || appOpenShowing || isFinishing || isDestroyed) return
        val ad = appOpenAd
        if (ad == null) {
            loadAppOpenAd()
            return
        }
        val now = System.currentTimeMillis()
        if (now - appOpenLoadedAt > APP_OPEN_AD_MAX_AGE_MS) {
            appOpenAd = null
            loadAppOpenAd()
            return
        }
        val lastShown = getSharedPreferences(PREFS_ADS, MODE_PRIVATE).getLong(KEY_LAST_APP_OPEN_SHOWN, 0L)
        if (now - lastShown < APP_OPEN_COOLDOWN_MS) return

        appOpenAd = null
        appOpenShowing = true
        fullScreenAdShowing = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                getSharedPreferences(PREFS_ADS, MODE_PRIVATE).edit().putLong(KEY_LAST_APP_OPEN_SHOWN, System.currentTimeMillis()).apply()
            }

            override fun onAdDismissedFullScreenContent() {
                appOpenShowing = false
                fullScreenAdShowing = false
                Log.d(TAG_ADS, "App Open ad closed.")
                loadAppOpenAd()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                appOpenShowing = false
                fullScreenAdShowing = false
                Log.w(TAG_ADS, "App Open ad could not be shown: ${error.message}")
                loadAppOpenAd()
            }
        }
        ad.show(this)
    }

    private fun restoreAdFreeReward() {
        val savedUntil = getSharedPreferences(PREFS_ADS, MODE_PRIVATE).getLong(KEY_AD_FREE_UNTIL, 0L)
        if (savedUntil > System.currentTimeMillis()) {
            adFreeUntilMillis = savedUntil
            adFreeActive = true
            Handler(Looper.getMainLooper()).postDelayed({ refreshAdFreeReward() }, savedUntil - System.currentTimeMillis())
        } else {
            getSharedPreferences(PREFS_ADS, MODE_PRIVATE).edit().remove(KEY_AD_FREE_UNTIL).apply()
        }
    }

    private fun refreshAdFreeReward() {
        val active = adFreeUntilMillis > System.currentTimeMillis()
        adFreeActive = active
        if (!active) {
            getSharedPreferences(PREFS_ADS, MODE_PRIVATE).edit().remove(KEY_AD_FREE_UNTIL).apply()
            if (adsReady) {
                loadInterstitialAd()
                loadRewardedAd()
            }
        }
    }

    private fun grantAdFreeReward() {
        val until = System.currentTimeMillis() + AD_FREE_HOUR_MS
        adFreeUntilMillis = until
        adFreeActive = true
        getSharedPreferences(PREFS_ADS, MODE_PRIVATE).edit().putLong(KEY_AD_FREE_UNTIL, until).apply()
        Toast.makeText(this, "Reward unlocked: ads paused for 1 hour.", Toast.LENGTH_LONG).show()
        Handler(Looper.getMainLooper()).postDelayed({ refreshAdFreeReward() }, AD_FREE_HOUR_MS)
    }

    private fun loadInterstitialAd() {
        if (!adsEnabled || !adsReady || adFreeActive || interstitialAdUnitId.isBlank() || interstitialLoading || interstitialAd != null) return
        interstitialLoading = true
        InterstitialAd.load(this, interstitialAdUnitId, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialLoading = false
                interstitialAd = ad
                interstitialLoadedAt = System.currentTimeMillis()
                Log.d(TAG_ADS, "Interstitial ad loaded.")
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitialLoading = false
                interstitialAd = null
                Log.w(TAG_ADS, "Interstitial ad failed (${error.code}): ${error.message}")
            }
        })
    }

    private fun loadRewardedAd() {
        if (!adsEnabled || !adsReady || adFreeActive || rewardedAdUnitId.isBlank() || rewardedLoading || rewardedAd != null) return
        rewardedLoading = true
        RewardedAd.load(this, rewardedAdUnitId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedLoading = false
                rewardedAd = ad
                rewardedLoadedAt = System.currentTimeMillis()
                rewardedAdReady = true
                Log.d(TAG_ADS, "Rewarded ad loaded.")
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedLoading = false
                rewardedAd = null
                rewardedAdReady = false
                Log.w(TAG_ADS, "Rewarded ad failed (${error.code}): ${error.message}")
            }
        })
    }

    private fun showRewardedAd() {
        val ad = rewardedAd
        if (ad == null || System.currentTimeMillis() - rewardedLoadedAt > AD_FREE_HOUR_MS) {
            rewardedAd = null
            rewardedAdReady = false
            loadRewardedAd()
            return
        }
        rewardedAd = null
        rewardedAdReady = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                fullScreenAdShowing = false
                Log.d(TAG_ADS, "Rewarded ad closed.")
                loadRewardedAd()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                fullScreenAdShowing = false
                Log.w(TAG_ADS, "Rewarded ad could not be shown: ${error.message}")
                loadRewardedAd()
            }
        }
        fullScreenAdShowing = true
        ad.show(this) { rewardItem ->
            Log.d(TAG_ADS, "Reward earned (${rewardItem.amount} ${rewardItem.type}).")
            grantAdFreeReward()
        }
    }

    private fun onSuccessfulExport() {
        if (!adsEnabled || interstitialAdUnitId.isBlank() || adFreeActive) return
        val preferences = getSharedPreferences(PREFS_ADS, MODE_PRIVATE)
        val successfulExports = preferences.getInt(KEY_EXPORTS_SINCE_INTERSTITIAL, 0) + 1
        preferences.edit().putInt(KEY_EXPORTS_SINCE_INTERSTITIAL, successfulExports).apply()
        if (successfulExports < EXPORTS_PER_INTERSTITIAL) return

        val ad = interstitialAd
        if (ad == null || System.currentTimeMillis() - interstitialLoadedAt > AD_FREE_HOUR_MS) {
            interstitialAd = null
            loadInterstitialAd()
            return
        }
        preferences.edit().putInt(KEY_EXPORTS_SINCE_INTERSTITIAL, 0).apply()
        interstitialAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                fullScreenAdShowing = false
                Log.d(TAG_ADS, "Interstitial ad closed.")
                loadInterstitialAd()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                fullScreenAdShowing = false
                Log.w(TAG_ADS, "Interstitial ad could not be shown: ${error.message}")
                loadInterstitialAd()
            }
        }
        fullScreenAdShowing = true
        Log.d(TAG_ADS, "Showing interstitial at a completed-export transition (frequency cap: one per three successful exports).")
        ad.show(this)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable private fun MobileScreen() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var durationValue by remember { mutableStateOf("10") }
        var durationUnit by remember { mutableStateOf("minutes") }
        var clipLength by remember { mutableStateOf("20") }
        var clipUnit by remember { mutableStateOf("seconds") }
        var clipCount by remember { mutableStateOf("30") }
        var mode by remember { mutableStateOf("Exact Cut") }
        var showPrivacyPolicy by remember { mutableStateOf(false) }
        var start by remember { mutableStateOf("00:00:00") }
        var end by remember { mutableStateOf("00:10:00") }
        var busy by remember { mutableStateOf(false) }
        var percent by remember { mutableFloatStateOf(0f) }
        var message by remember { mutableStateOf("Choose a video stored on this phone to extract or cut clips.") }
        var result by remember { mutableStateOf("") }
        var durationUnitExpanded by remember { mutableStateOf(false) }
        var clipUnitExpanded by remember { mutableStateOf(false) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { videoUri = it; result = "" }

        Scaffold(bottomBar = {
            if (adsEnabled && bannerAdUnitId.isNotBlank() && !busy && !adFreeActive) {
                BannerAd(Modifier.fillMaxWidth(), bannerAdUnitId)
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_app_logo), contentDescription = "AI Video Extractor logo", modifier = Modifier.size(48.dp))
                    Text(APP_NAME, style = MaterialTheme.typography.headlineMedium)
                }
                Text("Cut and save videos directly on your phone. Your videos are processed 100% locally on this device.", style = MaterialTheme.typography.bodyMedium)
                if (adsEnabled && privacyOptionsRequired) {
                    TextButton(onClick = {
                        consentUiShowing = true
                        UserMessagingPlatform.showPrivacyOptionsForm(this@MainActivity) { formError ->
                            consentUiShowing = false
                            if (formError != null) Log.w(TAG_ADS, "Privacy options form unavailable: ${formError.message}")
                            val consentInformation = UserMessagingPlatform.getConsentInformation(this@MainActivity)
                            updatePrivacyOptionsState(consentInformation)
                            initializeAdsIfAllowed(consentInformation)
                        }
                    }) { Text("Privacy options") }
                }
                TextButton(onClick = { showPrivacyPolicy = true }) { Text("Privacy policy") }
                if (showPrivacyPolicy) {
                    AlertDialog(
                        onDismissRequest = { showPrivacyPolicy = false },
                        title = { Text("Privacy policy") },
                        text = {
                            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Videos selected from your phone are processed 100% locally on this device and saved to Movies. The app does not upload video files or frames to any server.")
                                Text("Google Mobile Ads may process IP address, ad interactions, diagnostics, device identifiers, and advertising ID for advertising, analytics, and fraud prevention. Google's policy: https://policies.google.com/privacy")
                                Text("Google UMP handles consent and privacy choices. Ads are requested only when UMP permits them. Use Privacy options to change choices when that control is shown.")
                                Text("Ad-free reward expiry and ad frequency settings are stored on this device. Output videos remain in Movies until you delete them. For the full policy and developer contact, see the Privacy Policy linked from the app's store listing.")
                            }
                        },
                        confirmButton = { TextButton(onClick = { showPrivacyPolicy = false }) { Text("Close") } },
                    )
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1 · Video source", style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Choose a video from phone") }
                        Text(videoUri?.let { "Selected video: ${it.lastPathSegment ?: "local video"}" } ?: "Select a video stored on your device to edit")
                        videoUri?.let { uri ->
                            AndroidView(factory = { VideoView(it).apply { tag = uri.toString(); setMediaController(android.widget.MediaController(it).also { controller -> controller.setAnchorView(this) }); setVideoURI(uri); setOnPreparedListener { player -> player.isLooping = false; seekTo(0); pause() } } }, update = { view -> if (view.tag != uri.toString()) { view.tag = uri.toString(); view.setVideoURI(uri); view.setOnPreparedListener { player -> player.isLooping = false; view.seekTo(0); view.pause() } } }, modifier = Modifier.fillMaxWidth().height(190.dp))
                        }
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("2 · Extraction settings", style = MaterialTheme.typography.titleMedium)
                        if (mode == "Exact Cut") {
                            Text("Output duration (30 seconds to 2 hours)", style = MaterialTheme.typography.labelMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                OutlinedTextField(durationValue, { durationValue = it; runCatching { durationSeconds(it, durationUnit, 30, 7200) }.onSuccess { end = addSeconds(start, it) } }, enabled = !busy, label = { Text("Length") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                                ExposedDropdownMenuBox(expanded = durationUnitExpanded, onExpandedChange = { durationUnitExpanded = !durationUnitExpanded }, modifier = Modifier.weight(1f)) {
                                    OutlinedTextField(durationUnit.replaceFirstChar { it.uppercase() }, {}, readOnly = true, label = { Text("Unit") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(durationUnitExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(durationUnitExpanded, { durationUnitExpanded = false }) { listOf("seconds", "minutes", "hours").forEach { choice -> DropdownMenuItem(text = { Text(choice.replaceFirstChar { it.uppercase() }) }, onClick = { durationUnit = choice; durationUnitExpanded = false; runCatching { durationSeconds(durationValue, durationUnit, 30, 7200) }.onSuccess { end = addSeconds(start, it) } }) } }
                                }
                            }
                        } else {
                            Text("AI highlight clips (saved as separate MP4 files)", style = MaterialTheme.typography.labelMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                OutlinedTextField(clipLength, { clipLength = it; runCatching { highlightSettings(it, clipUnit, clipCount).third }.onSuccess { end = addSeconds(start, it) } }, enabled = !busy, label = { Text("Each clip") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                                ExposedDropdownMenuBox(expanded = clipUnitExpanded, onExpandedChange = { clipUnitExpanded = !clipUnitExpanded }, modifier = Modifier.weight(1f)) {
                                    OutlinedTextField(clipUnit.replaceFirstChar { it.uppercase() }, {}, readOnly = true, label = { Text("Unit") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(clipUnitExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(clipUnitExpanded, { clipUnitExpanded = false }) { listOf("seconds", "minutes").forEach { choice -> DropdownMenuItem(text = { Text(choice.replaceFirstChar { it.uppercase() }) }, onClick = { clipUnit = choice; clipUnitExpanded = false; runCatching { highlightSettings(clipLength, clipUnit, clipCount).third }.onSuccess { end = addSeconds(start, it) } }) } }
                                }
                            }
                            OutlinedTextField(clipCount, { clipCount = it; runCatching { highlightSettings(clipLength, clipUnit, it).third }.onSuccess { end = addSeconds(start, it) } }, enabled = !busy, label = { Text("How many clips (combined max 2 hours)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Text(runCatching { "Combined output: ${formatDuration(highlightSettings(clipLength, clipUnit, clipCount).third)}" }.getOrElse { it.message ?: "Check clip settings." }, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("Mode", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { listOf("Exact Cut", "AI Highlights").forEach { option -> Row { RadioButton(mode == option, { mode = option }, enabled = !busy); Text(option, modifier = Modifier.padding(top = 12.dp)) } } }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(start, { start = it }, enabled = !busy, label = { Text("Start HH:MM:SS") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(end, { end = it }, enabled = !busy, label = { Text("End HH:MM:SS") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text("AI Highlights selects interesting scenes on-device and saves each selected clip as its own MP4 in Movies/AI Video Extractor.", style = MaterialTheme.typography.bodySmall)
                    }
                }

                LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(message, style = MaterialTheme.typography.bodyMedium)
                if (adsEnabled && rewardedAdUnitId.isNotBlank() && !adFreeActive) {
                    OutlinedButton(
                        enabled = !busy && rewardedAdReady,
                        onClick = { showRewardedAd() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(if (rewardedAdReady) "Watch an ad for 1 hour without ads" else "Reward ad loading…")
                    }
                }
                if (adFreeActive) Text("Ads are paused until ${java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(Date(adFreeUntilMillis))}.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(enabled = !busy, modifier = Modifier.weight(1f), onClick = {
                        val inputUri = videoUri
                        if (inputUri == null) { message = "Please choose a video file from your phone first."; return@Button }
                        val seconds = runCatching { parseTime(start) }.getOrElse { message = "Start time must be seconds or HH:MM:SS."; return@Button }
                        val finish = runCatching { parseTime(end) }.getOrElse { message = "End time must be seconds or HH:MM:SS."; return@Button }
                        val clipSeconds: Int
                        val numberOfClips: Int?
                        val wanted = try {
                            if (mode == "AI Highlights") {
                                val settings = highlightSettings(clipLength, clipUnit, clipCount)
                                clipSeconds = settings.first; numberOfClips = settings.second; settings.third
                            } else {
                                clipSeconds = 20; numberOfClips = null
                                durationSeconds(durationValue, durationUnit, 30, 7200)
                            }
                        } catch (e: Exception) { message = e.message ?: "Check duration settings."; return@Button }
                        if (finish - seconds < wanted) { message = "End time must be at least the selected duration after the start."; return@Button }
                        busy = true; extractionBusy = true; percent = 0f; result = ""; cancelRequested = false; message = "Preparing video…"
                        scope.launch {
                            var extractionSucceeded = false
                            try {
                                val saved = withContext(Dispatchers.IO) {
                                    val input = copyPickedVideo(context, inputUri)
                                    val srcDuration = videoDuration(input)
                                    if (srcDuration < wanted || finish > srcDuration) throw IllegalArgumentException("This video is shorter than the selected time range or output duration.")
                                    if (mode == "Exact Cut") {
                                        val output = File(cacheDir, "render_${System.currentTimeMillis()}.mp4")
                                        runFfmpeg(command(input, output, seconds, wanted), wanted) { p -> runOnUiThread { percent = p; message = "Creating MP4…" } }
                                        saveToMovies(context, output).toString()
                                    } else {
                                        val pieces = makeHighlights(input, wanted, seconds, finish, clipSeconds, numberOfClips ?: 1) { p, text -> runOnUiThread { percent = p; message = text } }
                                        pieces.mapIndexed { index, piece -> saveToMovies(context, piece, "AI_Video_Extractor_${System.currentTimeMillis()}_clip_${(index + 1).toString().padStart(2, '0')}.mp4").toString() }.joinToString("\n")
                                    }
                                }
                                result = saved; percent = 100f; message = if (mode == "AI Highlights") "${numberOfClips} separate clips saved to Movies/AI Video Extractor." else "Video saved to Movies/AI Video Extractor."
                                extractionSucceeded = true
                            } catch (e: Exception) { message = if (cancelRequested) "Cancelled." else (e.message ?: "Could not process this video.") }
                            finally {
                                cacheDir.listFiles()?.filter { it.name.startsWith("source_") || it.name.startsWith("download_") || it.name.startsWith("render_") || it.name.startsWith("concat_") || it.name.startsWith("clip_") || it.name.startsWith("frame_") }?.forEach { it.delete() }
                                busy = false; extractionBusy = false; activeSession = null
                            }
                            if (extractionSucceeded) onSuccessfulExport()
                        }
                    }) { Text("Start extraction") }
                    OutlinedButton(enabled = busy, onClick = { cancelRequested = true; FFmpegKit.cancel(); message = "Cancelling…" }) { Text("Cancel") }
                }
                if (result.isNotBlank()) Text("Saved video: $result", style = MaterialTheme.typography.bodySmall)

            }
        }
    }

    @Composable
    private fun BannerAd(modifier: Modifier = Modifier, adUnitId: String) {
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current
        val screenWidthDp = LocalConfiguration.current.screenWidthDp
        val availableWidth = (screenWidthDp - 32).coerceAtLeast(320)
        val adSize = remember(availableWidth) {
            AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, availableWidth)
        }
        val bannerHeightDp = remember(adSize) {
            adSize.height.coerceAtLeast(50).dp
        }

        var adViewRef by remember { mutableStateOf<AdView?>(null) }

        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_RESUME -> adViewRef?.resume()
                    Lifecycle.Event.ON_PAUSE -> adViewRef?.pause()
                    Lifecycle.Event.ON_DESTROY -> adViewRef?.destroy()
                    else -> Unit
                }
            }
            lifecycleOwner?.lifecycle?.addObserver(observer)
            onDispose {
                lifecycleOwner?.lifecycle?.removeObserver(observer)
                adViewRef?.destroy()
                adViewRef = null
            }
        }

        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(bannerHeightDp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(bannerHeightDp),
                factory = { ctx ->
                    AdView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        this.adUnitId = adUnitId
                        setAdSize(adSize)
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                Log.d(TAG_ADS, "Banner ad loaded successfully. UnitId: $adUnitId, size: ${adSize.width}x${adSize.height}, responseInfo: ${responseInfo}")
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                val errorReason = when (error.code) {
                                    AdRequest.ERROR_CODE_INTERNAL_ERROR -> "ERROR_CODE_INTERNAL_ERROR (0)"
                                    AdRequest.ERROR_CODE_INVALID_REQUEST -> "ERROR_CODE_INVALID_REQUEST (1)"
                                    AdRequest.ERROR_CODE_NETWORK_ERROR -> "ERROR_CODE_NETWORK_ERROR (2)"
                                    AdRequest.ERROR_CODE_NO_FILL -> "ERROR_CODE_NO_FILL (3)"
                                    else -> "ERROR_CODE_${error.code}"
                                }
                                Log.e(
                                    TAG_ADS,
                                    "Banner ad failed to load: $errorReason. Error code=${error.code}, message='${error.message}', domain='${error.domain}', cause=${error.cause}, responseInfo=${error.responseInfo}"
                                )
                            }

                            override fun onAdOpened() {
                                Log.d(TAG_ADS, "Banner ad opened.")
                            }

                            override fun onAdClicked() {
                                Log.d(TAG_ADS, "Banner ad clicked.")
                            }

                            override fun onAdImpression() {
                                Log.d(TAG_ADS, "Banner ad impression recorded.")
                            }
                        }
                        Log.d(TAG_ADS, "Starting banner ad load request for unitId: $adUnitId, adSize: ${adSize.width}x${adSize.height} (${bannerHeightDp})")
                        loadAd(AdRequest.Builder().build())
                        adViewRef = this
                    }
                },
                update = { /* Managed by AdView and lifecycle */ }
            )
        }
    }

    private fun copyPickedVideo(context: Context, uri: Uri): File {
        val file = File(cacheDir, "source_${System.currentTimeMillis()}.mp4")
        context.contentResolver.openInputStream(uri)?.use { src -> file.outputStream().use { output -> src.copyTo(output) } } ?: error("Could not open the selected video.")
        return file
    }

    private fun command(input: File, output: File, start: Double, duration: Int): String =
        "-y -ss $start -i ${quote(input.absolutePath)} -t $duration -map 0:v:0 -map 0:a? -c:v mpeg4 -q:v 3 -c:a aac -b:a 128k -movflags +faststart ${quote(output.absolutePath)}"


    private fun videoDuration(file: File): Double {
        val info = FFprobeKit.getMediaInformation(file.absolutePath).mediaInformation ?: error("FFprobe could not read this video.")
        return info.duration?.toDoubleOrNull() ?: error("The video duration could not be read.")
    }

    private suspend fun makeHighlights(input: File, wanted: Int, rangeStart: Double, rangeEnd: Double, clipSeconds: Int, clipCount: Int, update: (Float, String) -> Unit): List<File> {
        update(18f, "Analyzing scene changes…")
        val detect = FFmpegKit.execute("-hide_banner -loglevel info -i ${quote(input.absolutePath)} -vf \"select='gt(scene,0.18)',metadata=print:file=-\" -an -f null -")
        if (!ReturnCode.isSuccess(detect.returnCode)) error("FFmpeg scene analysis failed.")
        val logs = detect.allLogsAsString
        val scores = Regex("lavfi\\.scene_score=([0-9.]+)").findAll(logs).map { it.groupValues[1].toDoubleOrNull() ?: 0.0 }.toList()
        val times = Regex("pts_time:([0-9.]+)").findAll(logs).map { it.groupValues[1].toDoubleOrNull() ?: 0.0 }.toList()
        val changes = times.zip(scores)
        val stride = maxOf(5, min(20, clipSeconds / 2))
        val lastStart = rangeEnd - clipSeconds
        if (lastStart < rangeStart) error("The selected source range is shorter than one clip.")
        val starts = mutableSetOf<Double>()
        var nextStart = rangeStart
        while (nextStart <= lastStart) { starts += nextStart; nextStart += stride }
        var packedStart = rangeStart
        while (packedStart <= lastStart) { starts += packedStart; packedStart += clipSeconds }
        starts += lastStart
        val windows = starts.sorted().map { a ->
            val b = a + clipSeconds.toDouble()
            val local = changes.filter { it.first >= a && it.first < b }.map { it.second }
            val scene = if (local.isEmpty()) 0.01 else (local.average() + minOf(0.4, local.size * 0.08)).coerceAtMost(1.0)
            Triple(a, b, scene)
        }
        if (windows.size < clipCount) error("Not enough footage for $clipCount non-overlapping clips of $clipSeconds seconds each.")
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        val ai = mutableMapOf<Int, Double>()
        val sampleSet = windows.withIndex().sortedByDescending { it.value.third }.take(16)
        try {
            sampleSet.forEachIndexed { n, indexed ->
                if (cancelRequested) error("Cancelled.")
                update(20f + n * 0.2f, "AI is reviewing video frames on this phone…")
                val frame = File(cacheDir, "frame_${System.currentTimeMillis()}_$n.jpg")
                val sec = indexed.value.first + min(8.0, (indexed.value.second - indexed.value.first) / 2)
                val grab = FFmpegKit.execute("-y -v error -ss $sec -i ${quote(input.absolutePath)} -frames:v 1 -vf scale=320:-1 ${quote(frame.absolutePath)}")
                if (ReturnCode.isSuccess(grab.returnCode) && frame.exists()) {
                    val labels = Tasks.await(labeler.process(InputImage.fromFilePath(this, Uri.fromFile(frame))), 30, TimeUnit.SECONDS)
                    val engaging = listOf("person", "people", "sport", "dance", "music", "perform", "action", "animal", "vehicle", "game", "crowd", "event", "entertainment", "water", "sports")
                    val semantic = labels.sumOf { label -> label.confidence.toDouble() * if (engaging.any { label.text.lowercase(Locale.ROOT).contains(it) }) 1.0 else 0.3 }.coerceAtMost(1.0)
                    ai[indexed.index] = indexed.value.third * 0.45 + semantic * 0.55
                    frame.delete()
                }
            }
        } finally { labeler.close() }
        val ranked = windows.withIndex().map { (i, w) -> Triple(w.first, w.second, ai[i] ?: w.third) }.sortedByDescending { it.third }
        val chosen = mutableListOf<Triple<Double, Double, Double>>()
        fun canStillFit(selected: List<Triple<Double, Double, Double>>): Boolean {
            var cursor = rangeStart; var possible = selected.size
            selected.sortedBy { it.first }.forEach { clip ->
                possible += floor(((clip.first - cursor).coerceAtLeast(0.0) + 1e-6) / clipSeconds).toInt()
                cursor = clip.second
            }
            possible += floor(((rangeEnd - cursor).coerceAtLeast(0.0) + 1e-6) / clipSeconds).toInt()
            return possible >= clipCount
        }
        for (w in ranked) {
            if (chosen.any { w.first < it.second && w.second > it.first }) continue
            if (!canStillFit(chosen + w)) continue
            chosen += w
            if (chosen.size >= clipCount) break
        }
        if (chosen.size < clipCount) error("Not enough distinct source footage for the requested clips.")
        val chunks = chosen.sortedBy { it.first }.mapIndexed { i, w ->
            if (cancelRequested) error("Cancelled.")
            update(25f + (i.toFloat() / chosen.size) * 55f, "Creating highlight ${i + 1} of ${chosen.size}…")
            val part = File(cacheDir, "clip_${System.currentTimeMillis()}_$i.mp4")
            runFfmpeg("-y -ss ${w.first} -i ${quote(input.absolutePath)} -t ${w.second - w.first} -map 0:v:0 -map 0:a? -c:v mpeg4 -q:v 3 -c:a aac -b:a 128k ${quote(part.absolutePath)}", (w.second - w.first).toInt()) {}
            part
        }
        return chunks
    }

    private suspend fun runFfmpeg(command: String, seconds: Int, onProgress: (Float) -> Unit) = kotlinx.coroutines.suspendCancellableCoroutine<Unit> { continuation ->
        val session = FFmpegKit.executeAsync(command, { completed ->
            activeSession = null
            if (continuation.isActive) {
                if (ReturnCode.isSuccess(completed.returnCode)) continuation.resume(Unit) else continuation.resumeWith(Result.failure(IllegalStateException("FFmpeg could not create the MP4. Check available phone storage and supported input formats.")))
            }
        }, null, { stats -> if (seconds > 0 && continuation.isActive) onProgress((stats.time.toFloat() / (seconds * 1000f) * 100f).coerceIn(1f, 99f)) })
        activeSession = session
        continuation.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
    }

    private fun saveToMovies(context: Context, rendered: File, displayName: String? = null): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName ?: "AI_Video_Extractor_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) { put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/AI Video Extractor"); put(MediaStore.Video.Media.IS_PENDING, 1) }
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("Could not create an output video in Movies.")
        try {
            resolver.openOutputStream(uri)?.use { output -> rendered.inputStream().use { it.copyTo(output) } } ?: error("Could not write the output video.")
            if (Build.VERSION.SDK_INT >= 29) resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            return uri
        } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
    }
}

private fun parseTime(value: String): Double {
    val parts = value.trim().split(":").map { it.toDouble() }
    require(parts.size in 1..3 && parts.all { it >= 0 }) { "Enter seconds or HH:MM:SS." }
    return parts.reversed().mapIndexed { i, v -> v * 60.0.powInt(i) }.sum()
}

private fun durationSeconds(value: String, unit: String, minimum: Int, maximum: Int): Int {
    val amount = value.toIntOrNull() ?: throw IllegalArgumentException("Enter a whole-number duration.")
    val seconds = amount * (UNIT_SECONDS[unit] ?: throw IllegalArgumentException("Choose seconds, minutes, or hours."))
    require(amount > 0 && seconds in minimum..maximum) { "Duration must be between $minimum seconds and 2 hours." }
    return seconds
}

private fun highlightSettings(length: String, unit: String, countText: String): Triple<Int, Int, Int> {
    val seconds = durationSeconds(length, unit, 5, 7200)
    val count = countText.toIntOrNull() ?: throw IllegalArgumentException("Enter how many clips to make.")
    require(count in 1..1440) { "Choose between 1 and 1440 clips." }
    val total = seconds * count
    require(total <= 7200) { "Clip length × number of clips cannot exceed 2 hours." }
    return Triple(seconds, count, total)
}

private fun formatDuration(seconds: Int): String = when {
    seconds % 3600 == 0 -> "${seconds / 3600} hour(s)"
    seconds % 60 == 0 -> "${seconds / 60} minute(s)"
    else -> "$seconds seconds"
}

private fun addSeconds(value: String, seconds: Int): String {
    val total = runCatching { parseTime(value).toInt() }.getOrDefault(0) + seconds
    return "%02d:%02d:%02d".format(total / 3600, total % 3600 / 60, total % 60)
}

private fun Double.powInt(n: Int): Double = when (n) { 0 -> 1.0; 1 -> 60.0; else -> 3600.0 }
private fun quote(path: String) = "'${path.replace("'", "'\\''")}'"

