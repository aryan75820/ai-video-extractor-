$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleHome = Join-Path $Project '.gradle-home'
$TempDir = Join-Path $Project '.build-cache\tmp'
$AndroidUserHome = if ($env:ANDROID_USER_HOME) { $env:ANDROID_USER_HOME } else { Join-Path $env:USERPROFILE '.android' }
New-Item -ItemType Directory -Path $GradleHome,$TempDir,$AndroidUserHome -Force | Out-Null
$env:GRADLE_USER_HOME = $GradleHome
$env:TEMP = $TempDir
$env:TMP = $TempDir
$env:ANDROID_USER_HOME = $AndroidUserHome
$JavaHome = $env:JAVA_HOME
if ($JavaHome -and (Split-Path -Leaf $JavaHome) -notmatch '^jdk-17') { $JavaHome = $null }
if (-not $JavaHome -or -not (Test-Path (Join-Path $JavaHome 'bin\java.exe'))) {
    $TemurinRoot = Join-Path $env:ProgramFiles 'Eclipse Adoptium'
    if (Test-Path $TemurinRoot) {
        $Jdk17 = Get-ChildItem $TemurinRoot -Directory -Filter 'jdk-17*' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($Jdk17) { $JavaHome = $Jdk17.FullName }
    }
}
if (-not $JavaHome -or -not (Test-Path (Join-Path $JavaHome 'bin\java.exe'))) {
    throw 'JDK 17 is required. Install Eclipse Temurin JDK 17, then run this script again.'
}
$env:JAVA_HOME = $JavaHome
$env:Path = (Join-Path $JavaHome 'bin') + ';' + $env:Path
$DebugKeystore = Join-Path $Project '.build-cache\debug.keystore'
if (-not (Test-Path $DebugKeystore)) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $DebugKeystore) -Force | Out-Null
    & (Join-Path $JavaHome 'bin\keytool.exe') -genkeypair -keystore $DebugKeystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US'
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local debug signing key.' }
}
$Sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not $Sdk -or -not (Test-Path (Join-Path $Sdk 'platforms\android-35\android.jar'))) {
    throw "Android SDK Platform 35 is required. Install Android Studio and Android SDK Platform 35, accept its SDK licenses, and set ANDROID_SDK_ROOT. See README.md."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk
$Cache = Join-Path $Project '.build-cache'
$Gradle = Join-Path $Cache 'gradle-8.11.1\bin\gradle.bat'
if (-not (Test-Path $Gradle)) {
    New-Item -ItemType Directory -Path $Cache -Force | Out-Null
    $Zip = Join-Path $Cache 'gradle-8.11.1-bin.zip'
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $Zip
    Expand-Archive -LiteralPath $Zip -DestinationPath $Cache -Force
}
Push-Location $Project
try {
    & $Gradle --no-daemon --no-parallel --max-workers=1 --stacktrace assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'Android APK build failed. Review the Gradle error above.' }
    $Apk = Join-Path $Project 'app\build\outputs\apk\debug\app-debug.apk'
    $OutputDir = Join-Path (Split-Path -Parent $Project) 'outputs'
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    Copy-Item -LiteralPath $Apk -Destination (Join-Path $OutputDir 'AI-Video-Extractor-Android.apk') -Force
    Write-Host "Installable debug APK: $OutputDir\AI-Video-Extractor-Android.apk"
} finally { Pop-Location }
