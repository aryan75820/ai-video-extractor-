# AI Video Extractor for Android

This is a separate, standalone Android app. It processes local videos on the phone and saves MP4 results to **Movies/AI Video Extractor**. It does not connect to or require the Windows desktop app.

## App behavior

- Pick a video with Android's system file picker; preview stays paused until you tap Play.
- Set Exact Cut length from 30 seconds to 2 hours in seconds, minutes, or hours.
- Exact Cut makes a continuous MP4 cut from the start time.
- AI Highlights lets you choose clip length in seconds or minutes and the number of clips. It detects scene changes, samples frames, and uses bundled on-device ML Kit labels to rank moments. Each highlight is saved as its own MP4 in Movies/AI Video Extractor; the video stays on the phone.
- Custom AI Video Extractor logo appears on the app screen and Android launcher.
- Progress, cancellation, start/end bounds, and audio preservation.
- Optional adaptive banner ads on the idle app screen, hidden during video processing. App Open ads can show only after returning from background, only after consent flow, no more than once per four hours, and never while extracting or another full-screen ad is showing. Interstitials are capped at one per three successful exports. Rewarded ads grant one hour without ads. Failed ad requests do not block video processing.
- Online source support is limited to permitted HTTPS direct video files and archive.org hosts. The user must confirm that they have the rights and that the source allows the download. No DRM/access-control bypass.

## Build an installable APK

1. Install Android Studio from [developer.android.com/studio](https://developer.android.com/studio).
2. In Android Studio's SDK Manager, install **Android SDK Platform 35** and the Android SDK Build Tools. Accept the Android SDK license in Android Studio.
3. Install [Eclipse Temurin JDK 17 for Windows x64](https://adoptium.net/temurin/releases/?arch=x64&os=windows&package=jdk&version=17) using the MSI. On the Custom Setup screen, enable **Add to PATH** and **Set JAVA_HOME**.
4. Run `powershell -ExecutionPolicy Bypass -File .\build-apk.ps1` from this folder. This creates a debug APK for local testing.
5. The APK is copied to `..\outputs\AI-Video-Extractor-Android.apk`. Transfer it to the phone and tap it to install. Android will show its normal confirmation for installing an APK. This is a debug-signed sideload APK, not a Play Store release.

### One-click build and install

After Android Studio, SDK Platform 35, SDK Build Tools, SDK license acceptance, and JDK 17 are complete, run `powershell -ExecutionPolicy Bypass -File .\one-click-mobile.ps1`. It builds the APK. If an Android phone is connected with USB debugging enabled, it installs to that phone; otherwise it opens the APK location so you can transfer the APK and tap it on the phone. Android will still require its normal confirmation for sideloading.

The script downloads the pinned Gradle 8.11.1 distribution into `.build-cache`; Gradle downloads the pinned Maven dependencies. The SDK is intentionally not silently installed or licensed by the script. The script uses JDK 17 and checks for it before starting.

## Share the app outside the Play Store

Run `powershell -ExecutionPolicy Bypass -File .\build-release-apk.ps1` to build and verify the release APK and Android App Bundle. Outputs are `..\outputs\AI-Video-Extractor-Android-Release.apk` and `..\outputs\AI-Video-Extractor-Android-Release.aab`. The APK is for Uptodown/direct testing; a new Google Play app must be submitted as an AAB. The first run creates a private signing key and its local password file under `.build-cache`. Back up both `.build-cache\release.keystore` and `.build-cache\release-signing.properties` somewhere private. Never upload or share either file; share only the APK/AAB. Every later app update must use the same key unless you deliberately configure Play App Signing. If the key is lost, users will need to uninstall sideloaded installs before installing a build signed with a different key.

The release signing password is stored locally in the ignored `.build-cache` folder so repeat builds work on this Windows account. Protect this computer and make a private backup of the two signing files. This sideload APK can be hosted for free, but users must download it and approve Android's normal install prompt. A direct APK is not a Play Store upload package.

## Ads and store compatibility

This project uses Kotlin, Jetpack Compose, Gradle Kotlin DSL, Android Gradle Plugin 8.10.1, Kotlin 2.3.0, Gradle 8.11.1, package `com.aivideoextractor.mobile`, min SDK 29, compile SDK 35 and target SDK 36. Google Play requires new apps and app updates to target API 36 from 31 August 2026. This build keeps the currently installed stable Platform 35 for compilation; the project does not use API 36-only APIs.

The integration uses Google's official Google Mobile Ads SDK and UMP consent SDK. Debug builds use Google's official test App ID and test IDs for banner, App Open, interstitial, and rewarded. Release builds read production configuration from the ignored local `ads.properties` file. The App ID and at least one production ad-unit ID enable release ads; only placements with configured IDs can load. This project currently has owner-provided production IDs for banner and App Open. No production interstitial or rewarded IDs have been provided; those formats are disabled in release and use test IDs in debug. Do not test or click ads in a release build; use the debug APK.

AdMob's current supported third-party Android store list includes Amazon Appstore, OPPO App Market, Samsung Galaxy Store, VIVO App Store, and Xiaomi GetApps; it does not include Uptodown. Apps listed exclusively in unsupported stores cannot complete AdMob's app-readiness review and receive limited ad serving. Since this release plan includes both Uptodown and a public Google Play listing, AdMob can be linked to the supported Play listing, subject to AdMob review and approval. Uptodown says ad revenue belongs to the developer and also offers Uptodown Ads, but its current integrated ads program requires the app to be published on both Uptodown and Google Play and requires a partner compatibility check. See [AdMob store support](https://support.google.com/admob/answer/9989980), [Uptodown monetization](https://support.uptodown.com/hc/en-us/articles/4403243577613-Why-is-this-app-published-on-Uptodown), and [Uptodown Ads requirements](https://ads.uptodown.dev/ads/).

### Ad ID configuration and rollout

1. Create the Google Play listing and submit the signed AAB; new Play apps must publish with an Android App Bundle. Current Play submissions must target API 36 or later (from 31 August 2026). Complete required developer/app verification and Play Console review.
2. Distribute the same application ID (`com.aivideoextractor.mobile`) through Uptodown using the package their developer console accepts. AdMob does not list Uptodown as a supported store; Uptodown-only apps cannot complete AdMob app-readiness review and receive limited ad serving. A public supported Google Play listing can be linked, but that does not guarantee approval or fill.
3. In [AdMob](https://admob.google.com/), add the Android app, link its public Play Store listing, and complete app readiness. Configure applicable EEA, UK, and Swiss consent messages under Privacy & messaging. Add and verify `app-ads.txt` at the developer website declared in the Play listing.
3. Production values belong in the local, ignored `ads.properties` file; `ads.properties.example` documents the keys. The current configuration has the owner's App ID, banner ID and App Open ID. Interstitial and rewarded remain blank until the owner creates those separate formats and supplies their IDs:

   ```properties
   admobAppId=ca-app-pub-8251220250880290~6821098132
   bannerAdUnitId=ca-app-pub-8251220250880290/9002829333
   appOpenAdUnitId=ca-app-pub-8251220250880290/5162647519
   interstitialAdUnitId=
   rewardedAdUnitId=
   ```

   These current production IDs were supplied by the app owner. Ad unit IDs are configuration values, not private signing credentials. Keep `ads.properties` local; only share the example/config instructions, never the signing key.
4. Run `powershell -ExecutionPolicy Bypass -File .\build-release-apk.ps1` to produce the production-configured release APK. For all integration tests, use the debug APK: it uses Google's official test IDs. Never click live ads or test with a production-configured release APK. The current build does not make an interstitial or rewarded production request because their production units are missing.
5. Create separate interstitial and rewarded ad units in AdMob and add each ID to `ads.properties` only if you want those formats live. Never reuse the banner or App Open ID for another format.
6. Complete Play's store listing, content rating, Data safety, target-audience and privacy declarations. Check AdMob readiness, app-ads.txt verification and serving status in its dashboard. Build success and configured IDs do not mean the account/app is approved or earning.

### Privacy policy and store disclosures

`PRIVACY_POLICY.md` is a project-specific draft describing local video processing and ad SDK data. Before publishing, replace its developer contact placeholder, review it against your actual business and app behavior, host it at a stable public URL, and enter that URL in both store listings. Complete the Google Play Data safety form and Uptodown disclosures using the current SDK disclosures and the policy. Google's Mobile Ads disclosures include IP address, app interactions, diagnostics, and device/account identifiers (including advertising ID when available) for advertising, analytics and fraud prevention. Selected videos are not sent to the ad SDK. Consent uses UMP and the app provides the privacy-options entry point when required. Configure applicable consent messages in AdMob Privacy & messaging. See [UMP guidance](https://developers.google.com/admob/android/privacy) and [Google Play data disclosure](https://developers.google.com/admob/android/privacy/play-data-disclosure).

### Privacy and disclosures

The UMP SDK refreshes consent information on every launch, shows a required consent form before ads can be requested, and exposes a **Privacy options** entry point when required. Ad initialization is gated by `canRequestAds()`. If consent can't be established and no valid prior choice permits ads, requests remain blocked. Ad load/init failures are logged without blocking video extraction. The Google SDK contributes merged permissions; review the release manifest and disclosures after SDK changes.

## Dependencies

- FFmpegKit maintained Android LGPL build `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9` for FFmpeg/FFprobe processing. The GPL variant is not used.
- Google ML Kit bundled image-labeling model for on-device scene semantics.
- Jetpack Compose for the native Android interface.

This project needs Android SDK 35, JDK 17, and network access to fetch Gradle and Maven dependencies. The current AdMob configuration is not a dashboard/serving approval. Debug uses test IDs; release uses the supplied banner and App Open IDs only. APK builds must be verified after each source/configuration change, and ads still need physical-device validation using the debug/test setup. A signed AAB is required for a new Google Play submission; use the Play Console checklist before publishing.


