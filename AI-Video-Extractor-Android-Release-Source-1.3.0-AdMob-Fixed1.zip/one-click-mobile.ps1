$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path

# Build the APK using the pinned Gradle wrapper script.
& (Join-Path $Project 'build-apk.ps1')
$Apk = Join-Path $Project 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $Apk)) { throw 'APK build finished without producing the expected APK.' }

$Sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$Adb = if ($Sdk) { Join-Path $Sdk 'platform-tools\adb.exe' } else { $null }
if ($Adb -and (Test-Path $Adb)) {
    $Devices = @(& $Adb devices | Select-String '\tdevice$')
    if ($Devices.Count -gt 0) {
        & $Adb install -r $Apk
        if ($LASTEXITCODE -ne 0) { throw 'ADB could not install the APK. Unlock the phone and enable USB debugging, then retry.' }
        Write-Host 'AI Video Extractor is installed on the connected phone.'
        exit 0
    }
}

Write-Host 'APK is ready. Copy it to your Android phone, open it, and confirm Android’s install prompt.'
Start-Process explorer.exe -ArgumentList "/select,`"$Apk`""
