#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CACHE_DIR="${PROJECT_DIR}/.build-cache"
GRADLE_HOME_DIR="${PROJECT_DIR}/.gradle-home"
OUTPUTS_DIR="$(dirname "${PROJECT_DIR}")/outputs"

mkdir -p "${CACHE_DIR}" "${GRADLE_HOME_DIR}" "${OUTPUTS_DIR}"
export GRADLE_USER_HOME="${GRADLE_HOME_DIR}"

if ! command -v java >/dev/null 2>&1; then
    echo "ERROR: Java 17 is required but not installed or not in PATH."
    exit 1
fi

SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "${SDK_DIR}" ] || [ ! -d "${SDK_DIR}" ]; then
    echo "ERROR: ANDROID_HOME or ANDROID_SDK_ROOT must be set and point to a valid Android SDK installation (API 35)."
    exit 1
fi
export ANDROID_HOME="${SDK_DIR}"
export ANDROID_SDK_ROOT="${SDK_DIR}"

KEYSTORE="${CACHE_DIR}/release.keystore"
SIGNING_PROPS="${CACHE_DIR}/release-signing.properties"

if [ ! -f "${KEYSTORE}" ] || [ ! -f "${SIGNING_PROPS}" ]; then
    echo "Generating private release signing key under .build-cache..."
    STORE_PASS=$(head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 24)
    KEY_PASS="${STORE_PASS}"
    
    keytool -genkeypair -keystore "${KEYSTORE}" -storepass "${STORE_PASS}"         -alias aivideoextractor -keypass "${KEY_PASS}" -keyalg RSA -keysize 3072         -validity 10000 -dname "CN=AI Video Extractor,OU=Mobile,O=AI Video Extractor,L=Local,ST=Local,C=US"
    
    cat << PROP_EOF > "${SIGNING_PROPS}"
storeFile=.build-cache/release.keystore
storePassword=${STORE_PASS}
keyAlias=aivideoextractor
keyPassword=${KEY_PASS}
PROP_EOF
    echo "Release signing key created."
fi

GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then
    GRADLE_BIN="gradle"
elif [ -f "${CACHE_DIR}/gradle-8.11.1/bin/gradle" ]; then
    GRADLE_BIN="${CACHE_DIR}/gradle-8.11.1/bin/gradle"
elif [ -f "${PROJECT_DIR}/gradlew" ]; then
    GRADLE_BIN="${PROJECT_DIR}/gradlew"
else
    echo "Downloading Gradle 8.11.1..."
    curl -fsSL "https://services.gradle.org/distributions/gradle-8.11.1-bin.zip" -o "${CACHE_DIR}/gradle-8.11.1-bin.zip"
    unzip -q -o "${CACHE_DIR}/gradle-8.11.1-bin.zip" -d "${CACHE_DIR}"
    GRADLE_BIN="${CACHE_DIR}/gradle-8.11.1/bin/gradle"
    chmod +x "${GRADLE_BIN}"
fi

echo "Building release APK..."
cd "${PROJECT_DIR}"
"${GRADLE_BIN}" --no-daemon --no-parallel --max-workers=1 assembleRelease bundleRelease

APK_SRC="${PROJECT_DIR}/app/build/outputs/apk/release/app-release.apk"
APK_DEST="${OUTPUTS_DIR}/AI-Video-Extractor-Android-Release.apk"
if [ -f "${APK_SRC}" ]; then
    cp -f "${APK_SRC}" "${APK_DEST}"
    echo "Release APK built successfully: ${APK_DEST}"
else
    echo "ERROR: Built APK not found at ${APK_SRC}"
    exit 1
fi

AAB_SRC="${PROJECT_DIR}/app/build/outputs/bundle/release/app-release.aab"
AAB_DEST="${OUTPUTS_DIR}/AI-Video-Extractor-Android-Release.aab"
if [ -f "${AAB_SRC}" ]; then
    cp -f "${AAB_SRC}" "${AAB_DEST}"
    echo "Release AAB built successfully: ${AAB_DEST}"
fi
