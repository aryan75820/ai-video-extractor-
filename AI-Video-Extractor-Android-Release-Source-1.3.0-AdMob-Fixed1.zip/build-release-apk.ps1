$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cache = Join-Path $Project '.build-cache'
$GradleHome = Join-Path $Project '.gradle-home'
$TempDir = Join-Path $Cache 'tmp'
$AndroidUserHome = if ($env:ANDROID_USER_HOME) { $env:ANDROID_USER_HOME } else { Join-Path $env:USERPROFILE '.android' }
New-Item -ItemType Directory -Path $Cache,$GradleHome,$TempDir,$AndroidUserHome -Force | Out-Null
$env:GRADLE_USER_HOME = $GradleHome
$env:TEMP = $TempDir
$env:TMP = $TempDir
$env:ANDROID_USER_HOME = $AndroidUserHome

$JavaHome = $env:JAVA_HOME
if ($JavaHome -and (Split-Path -Leaf $JavaHome) -notmatch '^jdk-17') { $JavaHome = $null }
if (-not $JavaHome -or -not (Test-Path (Join-Path $JavaHome 'bin\java.exe'))) {
    $TemurinRoot = Join-Path $env:ProgramFiles 'Eclipse Adoptium'
    if (Test-Path $TemurinRoot) {
        $Jdk17 = Get-ChildItem $TemurinRoot -Directory -Filter 'jdk-17*' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($Jdk17) { $JavaHome = $Jdk17.FullName }
    }
}
if (-not $JavaHome -or -not (Test-Path (Join-Path $JavaHome 'bin\java.exe'))) {
    throw 'JDK 17 is required. Install Eclipse Temurin JDK 17, then run this script again.'
}
$env:JAVA_HOME = $JavaHome
$env:Path = (Join-Path $JavaHome 'bin') + ';' + $env:Path

$Sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not $Sdk -or -not (Test-Path (Join-Path $Sdk 'platforms\android-35\android.jar'))) {
    throw "Android SDK Platform 35 is required. Install it in Android Studio and accept its license. See README.md."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

$Gradle = Join-Path $Cache 'gradle-8.11.1\bin\gradle.bat'
if (-not (Test-Path $Gradle)) {
    $Zip = Join-Path $Cache 'gradle-8.11.1-bin.zip'
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $Zip
    Expand-Archive -LiteralPath $Zip -DestinationPath $Cache -Force
}

$Keystore = Join-Path $Cache 'release.keystore'
$SigningProperties = Join-Path $Cache 'release-signing.properties'
if ((Test-Path $Keystore) -xor (Test-Path $SigningProperties)) {
    throw 'Release signing files are incomplete. Keep both .build-cache\release.keystore and release-signing.properties together.'
}
if (-not (Test-Path $Keystore)) {
    $Alphabet = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    $Random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $Bytes = New-Object byte[] 48
        $Random.GetBytes($Bytes)
        $StorePassword = -join ($Bytes | ForEach-Object { $Alphabet[[int]$_ % $Alphabet.Length] })
        # PKCS12 uses the same password for the key entry and the keystore.
        $KeyPassword = $StorePassword
    } finally { $Random.Dispose() }
    $Keytool = Join-Path $JavaHome 'bin\keytool.exe'
    & $Keytool -genkeypair -keystore $Keystore -storepass $StorePassword -alias aivideoextractor -keypass $KeyPassword -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=AI Video Extractor,OU=Mobile,O=AI Video Extractor,L=Local,ST=Local,C=US'
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local release signing key.' }
    @(
        'storeFile=.build-cache/release.keystore'
        "storePassword=$StorePassword"
        'keyAlias=aivideoextractor'
        "keyPassword=$KeyPassword"
    ) | Set-Content -LiteralPath $SigningProperties -Encoding ASCII
    Write-Host 'Created a private release signing key under mobile-android\.build-cache.'
}

Push-Location $Project
try {
    & $Gradle --no-daemon --no-parallel --max-workers=1 --stacktrace assembleRelease bundleRelease
    if ($LASTEXITCODE -ne 0) { throw 'Release APK/AAB build failed. Review the Gradle error above.' }
    $Apk = Join-Path $Project 'app\build\outputs\apk\release\app-release.apk'
    $OutputDir = Join-Path (Split-Path -Parent $Project) 'outputs'
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    $OutputApk = Join-Path $OutputDir 'AI-Video-Extractor-Android-Release.apk'
    Copy-Item -LiteralPath $Apk -Destination $OutputApk -Force
    $Bundle = Join-Path $Project 'app\build\outputs\bundle\release\app-release.aab'
    $OutputBundle = Join-Path $OutputDir 'AI-Video-Extractor-Android-Release.aab'
    Copy-Item -LiteralPath $Bundle -Destination $OutputBundle -Force
    $ApkSigner = Get-ChildItem (Join-Path $Sdk 'build-tools') -Directory | Sort-Object Name -Descending | Select-Object -First 1 | ForEach-Object { Join-Path $_.FullName 'apksigner.bat' }
    & $ApkSigner verify --verbose $OutputApk
    if ($LASTEXITCODE -ne 0) { throw 'The generated release APK signature did not verify.' }
    & (Join-Path $JavaHome 'bin\jarsigner.exe') -verify $OutputBundle 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'The generated release AAB signature did not verify.' }
    Write-Host "Release-signed APK: $OutputApk"
    Write-Host "Release-signed AAB for Google Play: $OutputBundle"
    Write-Host 'AAB signature verified (the local upload certificate is self-signed; configure Play App Signing when creating the Play release).'
    Write-Host 'Keep .build-cache\release.keystore and release-signing.properties private and backed up. Future updates must use this same signing key.'
} finally { Pop-Location }
